Motion assets placeholder
