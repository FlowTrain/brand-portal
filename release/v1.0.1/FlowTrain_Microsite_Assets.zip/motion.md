
---
layout: default
title: Motion & Visual Language
---

# Motion & Visual Language

Flow Train motion conveys **speed, clarity, and flow**. Use seamless loops with subtle glow accents.

- Splash loops (MP4)
- Lock-screen animations

[Next: Productivity & Tools →](productivity.md)
