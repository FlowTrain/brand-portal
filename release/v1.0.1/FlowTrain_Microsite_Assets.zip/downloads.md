
---
layout: default
title: Downloads
---

# Downloads

## System Themes
- Windows `.deskthemepack`
- macOS wallpapers
- Cursor packs

## Documentation Kits
- Notion templates
- Confluence templates
- GitHub README templates

## Motion Assets
- Splash MP4
- Lock screen animation
