
---
layout: default
title: Productivity & Tools
---

# Productivity & Tools

## Office Theme
Use the Flow Train Office XML for consistent document colors.

## VS Code Theme
Apply the Flow Train dark theme JSON.

## Teams Backgrounds
Use branded backgrounds for calls.

[Next: Training Themes →](training-themes.md)
