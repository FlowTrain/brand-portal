Windows Theme Pack placeholder
