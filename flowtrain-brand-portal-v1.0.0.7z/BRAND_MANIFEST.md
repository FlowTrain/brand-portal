
# Flow Train — Brand Manifest

## Principles
- Flow over friction
- Learning by doing
- Clarity beats decoration

## Brand Colors (Screen / RGB)
- Flow Train Blue: #2BAEE4
- Near Black: #231F20

## Governance
This repository version is authoritative.
Do not fork branding assets without review.

