
# Notion Style Guide — Flow Train

## Headings
- H1: Page title only
- H2: Main sections
- H3: Subsections

## Callouts
- 💡 Principle
- ⚠️ Warning
- 🧪 Exercise

## Code Blocks
Always specify language and keep examples minimal.

